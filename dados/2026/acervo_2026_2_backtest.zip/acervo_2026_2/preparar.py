import csv,json,pathlib,hashlib,datetime
P=pathlib.Path(__file__).resolve().parent
manifest=json.loads((P/'manifest.json').read_bytes())
for name,h in manifest['files'].items():
 assert hashlib.sha256((P/'raw'/name).read_bytes()).hexdigest()==h,name
x=json.loads((P/'raw/1.json').read_bytes());assert (x['year'],x['turn'],x['cargo'],x['simulation'],x['live'])==(2026,2,1,False,True)
assert list(x['candidates']['BR'])==['13','22']
fields=['timestamp','scope','uf','municipio_tse','secoes_contabilizadas','eleitores_secoes_contabilizadas','comparecimento','brancos','nulos','votos_13','votos_22']
issues=[];stats={};finals=[]
def rows(scope,uf,mun,s):
 previous=-1
 for r in s['series']:
  assert len(r)==8 and all(isinstance(v,int) and v>=0 for v in r),(scope,r)
  assert r[0]>previous,(scope,'tempo duplicado ou regressivo');previous=r[0]
  if r[3]!=sum(r[4:]):issues.append([scope,r[0],'comparecimento difere de brancos+nulos+nominais',r[3]-sum(r[4:])])
  if r[3]>r[2]:issues.append([scope,r[0],'comparecimento maior que eleitorado contabilizado'])
  t=datetime.datetime.fromisoformat(x['date']+'T00:00:00-03:00')+datetime.timedelta(seconds=r[0])
  yield [t.isoformat(),scope,uf,mun,*r[1:]]
 if s['series'] and s['series'][-1][1:]!=s['total']:issues.append([scope,'ultimo ponto difere de total'])
 finals.append(dict(scope=scope,uf=uf,municipio_tse=mun,total=s['total'],finished=s.get('finished'),lastReceivedAt=s.get('lastReceivedAt'),sourceGeneratedAt=s.get('sourceGeneratedAt')))
for filename,gen in [('observacoes_nacional_uf.csv',((code,code if code!='BR' else '', '',s) for code,s in x['states'].items())),('observacoes_municipais.csv',((uf+':'+code,uf,code,s) for uf in [n[2:-5] for n in manifest['files'] if n.startswith('1_')] for code,s in json.loads((P/'raw'/('1_'+uf+'.json')).read_bytes())['municipalities'].items()))]:
 count=0
 with (P/filename).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(fields)
  for scope,uf,mun,s in gen:
   for r in rows(scope,uf,mun,s):w.writerow(r);count+=1
 stats[filename]=count
# Final labels are isolated; never expose these to an estimator at earlier cutoffs.
(P/'alvos_finais.json').write_text(json.dumps(finals,ensure_ascii=False,indent=2))
national=x['states']['BR']['total'];ufs=[v['total'] for k,v in x['states'].items() if k!='BR'];delta=[sum(r[i] for r in ufs)-national[i] for i in range(7)]
report=dict(manifest_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),files_verified=len(manifest['files']),presidential_files=29,rows=stats,issues=issues,national_final=national,uf_sum_minus_national=delta,repo_reference='bff6ef51cb40a73d1874872e9db9769fe6cb23e9',temporal_precision_seconds=x['precision_seconds'])
(P/'validacao.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False)[:5000])
