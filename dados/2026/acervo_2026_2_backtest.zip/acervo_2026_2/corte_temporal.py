"""Uso: python corte_temporal.py 2026-10-25T20:00:00-03:00 > corte.json
Apenas observações até o corte; não lê alvos finais, percentuais finais nem declarações.
"""
import csv,json,datetime,pathlib,sys
cut=datetime.datetime.fromisoformat(sys.argv[1]);assert cut.tzinfo,'Exigir fuso no corte'
P=pathlib.Path(__file__).resolve().parent
result={}
for name in ['observacoes_nacional_uf.csv','observacoes_municipais.csv']:
 for r in csv.DictReader((P/name).open()):
  t=datetime.datetime.fromisoformat(r['timestamp'])
  if t<=cut and (r['scope'] not in result or t>datetime.datetime.fromisoformat(result[r['scope']]['timestamp'])):
   result[r['scope']]={k:(int(v) if k not in ['timestamp','scope','uf','municipio_tse'] else v) for k,v in r.items()}
print(json.dumps({'cutoff':cut.isoformat(),'observations':result},ensure_ascii=False))
