# Acervo externo para backtest temporal — presidencial 2026, segundo turno

Fonte: https://numerosdaeleicao.com.br/fontes
Manifesto: https://numerosdaeleicao.com.br/live/elections/2026-2/manifest.json
Objetos: https://numerosdaeleicao.com.br/live/objects/{SHA256}.json
Recuperação: 30/10/2026. Manifesto publicado em 27/10/2026, eleição 2026-2, checkpoint 86896, recording.complete=true.

36 objetos originais preservados e hashes SHA-256 conferidos nos bytes baixados. Os 29 objetos de cargo 1 cobrem o nacional e arquivos municipais das 27 UFs e exterior. Os sete objetos de cargo 3 foram preservados para completar a verificação do manifesto, mas não entram nos CSVs presidenciais. integridade.json registra esperado, calculado, tamanho e resultado por objeto. O hash do próprio manifesto é local; não existe aqui uma assinatura independente que o autentique.

## Dados preparados

observacoes_nacional_uf.csv: 4.892 pontos; nacional BR, 27 UFs e ZZ (exterior).
observacoes_municipais.csv: 47.139 pontos, com chave UF:código municipal TSE.
alvos_finais.json: totais publicados separados das entradas. A flag finished foi preservada, sem interpretar ausência ou false como inexistência de votos.
validacao.json: verificações e referência do repositório inspecionado.

Colunas originais da série: segundo desde meia-noite de Brasília; seções contabilizadas; eleitores das seções contabilizadas; comparecimento; brancos; nulos; votos 13; votos 22. Os CSVs convertem o primeiro campo para ISO 8601 com UTC−03:00. Ordem das candidaturas conferida no objeto nacional. Não são incrementos: cada linha representa contadores acumulados. Não somar BR com UFs, nem UFs com municípios.

Verificações: todos os hashes; ano/turno/cargo; inteiros não negativos; sequência temporal estritamente crescente por território; comparecimento = brancos+nulos+13+22; comparecimento <= eleitores contabilizados; último ponto igual ao total publicado. Nenhuma falha nessas verificações. A soma final das UFs e ZZ coincide com BR nos sete contadores. Isso não demonstra sincronismo entre séries territoriais durante a noite.

## Uso sem informação futura

1. Execute `python recuperar.py` para baixar novamente os objetos endereçados pelo manifesto preservado.
2. Execute `python preparar.py` para validar e regenerar CSVs e alvos.
3. Execute `python corte_temporal.py 2026-10-25T20:00:00-03:00 > corte.json`.
4. Entregue ao modelo somente `observations` do corte. O leitor usa a última observação de cada território com timestamp <= corte, sem interpolação. Territórios ainda ausentes devem permanecer ausentes. Cada observação mantém seu horário próprio, permitindo medir defasagem.
5. Use alvos_finais.json apenas depois de congelar previsões para avaliar erro. Não use total final de votos para construir features ou percentuais de avanço. Seções previstas/eleitorado total só podem ser usados se vierem de uma fonte documentada disponível antes do corte.

A abertura artificial com contadores zerados existe no nacional/UF; não é evidência de uma coleta oficial com zero voto. Deve ser excluída de métricas de previsão quando não há votos observados.

## Relação com o repositório

Repositório consultado: fabiooliveira-source/paineleleitoral-2026, árvore main bff6ef51cb40a73d1874872e9db9769fe6cb23e9. A árvore consultada não possui arquivo identificado pelo nome como backtest temporal. scripts/prepare-model-input.cjs monta dados finais por seção para inferência entre turnos; esse contrato não é uma série temporal de apuração. Os CSVs e o leitor são uma entrada externa independente; não substituem esse script nem convertem agregados em seções fictícias. Nenhuma alteração remota foi efetuada. A integração ao estimador específico ainda precisa respeitar seu contrato; o backtest do algoritmo não foi executado nesta entrega.

## Limites da evidência

Os objetos declaram live=true, simulation=false e precisão de um segundo. São séries agregadas publicadas pelo acervo, não os arquivos brutos de cada resposta TSE ou suas assinaturas. Horário da série não comprova sozinho o instante de disponibilização pública pelo TSE; sourceGeneratedAt e lastReceivedAt existentes no objeto são metadados finais, não pares por observação. A página inicial contém texto genérico de reconstrução com BUs; por isso a classificação desta entrega se baseia no manifesto e nos objetos live, preservados, e não naquele texto. A integridade SHA-256 prova correspondência com este manifesto; não certifica origem TSE, completude da captura, independência estatística nem ausência de alterações antes da publicação. O resultado final do próprio acervo é um alvo interno, ainda sujeito a confronto independente com uma fonte oficial autenticada.
