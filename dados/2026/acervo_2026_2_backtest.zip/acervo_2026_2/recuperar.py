import json,hashlib,subprocess,concurrent.futures,pathlib
P=pathlib.Path(__file__).resolve().parent
m=json.loads((P/'manifest.json').read_bytes())
def fetch(item):
 name,h=item;p=P/'raw'/name
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:
  subprocess.run(['curl','-fsS','--retry','2','--max-time','60','https://numerosdaeleicao.com.br/live/objects/'+h+'.json','-o',str(p)],check=True)
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 return dict(file=name,expected=h,actual=actual,ok=actual==h,bytes=p.stat().st_size)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:r=list(ex.map(fetch,m['files'].items()))
(P/'integridade.json').write_text(json.dumps(r,indent=2))
print('Verificados',len(r),'OK',sum(x['ok'] for x in r),'bytes',sum(x['bytes'] for x in r))
assert all(x['ok'] for x in r)
